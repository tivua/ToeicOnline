use toeiconline;

INSERT INTO exercisetype(name, code, createddate) VALUES ('Bài tập phần nghe', 'listening', CURRENT_TIMESTAMP);
INSERT INTO exercisetype(name, code, createddate) VALUES ('Bài tập phần đọc', 'reading', CURRENT_TIMESTAMP);


