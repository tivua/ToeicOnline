user toeiconline;
ALTER TABLE user ADD UNIQUE (name);
