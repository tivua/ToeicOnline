use toeiconline;
INSERT INTO user(name, password, fullname, createddate, roleid) VALUES('admin', '123456', 'admin',CURRENT_TIMESTAMP, 1);
INSERT INTO user(name, password, fullname, createddate, roleid) VALUES('truongtunglam', '123456', 'truong tung lam',CURRENT_TIMESTAMP, 2);




