USE toeiconline;

INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 1', 'Noi dung bai hd 1', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 2', 'Noi dung bai hd 2', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 3', 'Noi dung bai hd 3', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 4', 'Noi dung bai hd 4', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 5', 'Noi dung bai hd 5', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 6', 'Noi dung bai hd 6', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 7', 'Noi dung bai hd 7', CURRENT_TIMESTAMP);
INSERT INTO listenguideline(title, content, createddate) VALUES ('Bai hd 8', 'Noi dung bai hd 8', CURRENT_TIMESTAMP);