package vn.sinbad.core.common.constant;

public class CoreConstant {

}
