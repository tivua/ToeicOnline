package vn.sinbad.core.data.daoimpl;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import vn.sinbad.core.common.utils.HibernateUtils;
import vn.sinbad.core.data.dao.GenericDao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class AbstractDao<ID extends Serializable, T> implements GenericDao<ID, T> {

    //2 - phuong thuc lay entity, tuc la lay ten class do, vid du : UserDao, dua vao tien to nay  de lay va ghep vao persistenceClass
    private Class<T> persistenceClass;

    //3 -  de persistenceClass co gia tri, ta tao constructor Abstractor() -> khoi tao gia tri ban dau cho bien,
    public AbstractDao() {
        // 4 - ParameterizedType se lay mang [ID, T], sau do se lay vi tri getActualTypeArguments,
        // la vi tri that -> vi tri thu 1 -> la T,
        this.persistenceClass = (Class<T>) ((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[1];
    }

    //5 - chuyen tu Class<T> lay duoc sang String
    //vi du "select * from user" -> user la string, nhung persistenceClass la Class<T>
    // 6 - ham lay ten class entity
    public String getPersistenceClassName() {
        return persistenceClass.getSimpleName();
    }

    // 1 - xay dung doi tuong session de su dung --> tu getSessionFactory()
    protected Session getSession() {
        return HibernateUtils.getSessionFactory().openSession();
    }

    public List<T> findAll() {
        List<T> list = new ArrayList<T>();
        Transaction transaction = null;

        try {
            transaction = getSession().beginTransaction();
            //HQL  --> da co ham getPersistenceClassName() lay ten class entity : User, Comment, Role,....
            StringBuilder sql = new StringBuilder("from ");
            //lay ten entity
            sql.append(this.getPersistenceClassName());
            Query query = this.getSession().createQuery(sql.toString());
            list = query.list();
            transaction.commit();
        }catch (HibernateException e){
            transaction.rollback();
            throw e;
        }

        return list;
    }
}
